package com.cg.spring.lab2;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Application1 
{
    public static void main( String[] args )
    {
        System.out.println( "Start" );
        ApplicationContext context = new ClassPathXmlApplicationContext("SpringConfig.xml");
        Employees employee = context.getBean("employee", Employees.class);
       System.out.println("Employee Details");
        System.out.println("-----------------------");
       System.out.println(employee.toString());
       SBu sbu = context.getBean("sbu", SBu.class);
        System.out.println("SBU Details");
        System.out.println("-----------------------");
       System.out.println(sbu.toString());
        
    }
}
