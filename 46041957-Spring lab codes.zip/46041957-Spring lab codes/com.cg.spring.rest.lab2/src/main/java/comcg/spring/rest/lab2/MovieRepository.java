package comcg.spring.rest.lab2;

	import org.springframework.data.repository.CrudRepository;

	public interface MovieRepository extends CrudRepository<Movies, String> {

	}


