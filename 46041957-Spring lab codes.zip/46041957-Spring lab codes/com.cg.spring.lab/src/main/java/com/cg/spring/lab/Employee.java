package com.cg.spring.lab;
import java.util.List;

import org.springframework.stereotype.Component;

//@Component
@SuppressWarnings("unused")
public class Employee {
	private int employeeid;
    private String employeename;
    private double salary;
    private String bussinessUnit;
    private int age;
    
    public Employee() {
		super();
	}

	public Employee(int employeeid, String employeename, double salary, String bussinessUnit, int age) {
		super();
		this.employeeid = employeeid;
		this.employeename = employeename;
		this.salary = salary;
		this.bussinessUnit = bussinessUnit;
		this.age = age;
	}

	public int getEmployeeid() {
		return employeeid;
	}

	public void setEmployeeid(int employeeid) {
		this.employeeid = employeeid;
	}

	public String getEmployeename() {
		return employeename;
	}

	public void setEmployeename(String employeename) {
		this.employeename = employeename;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public String getBussinessUnit() {
		return bussinessUnit;
	}

	public void setBussinessUnit(String bussinessUnit) {
		this.bussinessUnit = bussinessUnit;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	@Override
	public String toString() {
		return "Employee Id : " + employeeid + " \nEmployee Name : " + employeename + " \nSalary : " + salary
				+ " \nEmlpoyee BU : " + bussinessUnit + " \nEmployee age : " + age + " ";
	}
}
