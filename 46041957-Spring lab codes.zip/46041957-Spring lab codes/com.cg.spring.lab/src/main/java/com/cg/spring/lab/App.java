package com.cg.spring.lab;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Hello world!
 *
 */
//@ComponentScan
@SuppressWarnings("unused")
public class App {
	public static void main(String[] args) {
		System.out.println("Start");
		@SuppressWarnings("resource")
		ApplicationContext context = new ClassPathXmlApplicationContext("Springconfig.xml");
		Employee employee = context.getBean("employee",Employee.class);
		System.out.println("Employee Details");
		System.out.println("---------------------");
        System.out.println(employee.toString());
	}
}