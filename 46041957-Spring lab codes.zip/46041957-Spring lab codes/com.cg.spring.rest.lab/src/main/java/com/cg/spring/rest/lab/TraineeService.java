package com.cg.spring.rest.lab;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
 
@Service
public class TraineeService {
 	@Autowired
 	TraineeRepository traineeRepo;
 	public List<Trainee> getAllTrainee() {
       	List<Trainee> trainee = new ArrayList<Trainee>();
       	traineeRepo.findAll().forEach(trainee1 -> trainee.add(trainee1));
       	return trainee;
 	}
 	public List<Trainee> getTraineeByName(String traineeName) {
 		List<Trainee> trainee = new ArrayList<Trainee>();
       	traineeRepo.findAll().forEach(trainee1 -> trainee.add(trainee1));
		return trainee;
 	}
 	 	public List<Trainee> getTraineeById(int traineeId) {
 	 		List<Trainee> trainee = new ArrayList<Trainee>();
 	       	traineeRepo.findAll().forEach(trainee1 -> trainee.add(trainee1));
 			return trainee;
 	 	}
 	  	
 	public void saveOrUpdate(Trainee trainee) {
       	traineeRepo.save(trainee);
 	}
 	public void delete(int id) {
       	traineeRepo.deleteById(id);
 	}
 
 	public void update(Trainee trainee, int eid) {
       	traineeRepo.save(trainee);
 	}
}
