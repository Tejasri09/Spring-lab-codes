package com.cg.spring.rest.lab;
import org.springframework.data.repository.CrudRepository;

public interface TraineeRepository extends CrudRepository<Trainee, Integer> {
}
